module Ashton
  VERSION = "0.1.3"
end
